class Employee:
    pass

john=Employee()
john.name='John Doe'
john.dept='Computer lab'
john.salary=56000
print(john.name)
print(john.dept)
print(john.salary)