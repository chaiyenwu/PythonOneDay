import Shape1
p=Shape1.Point(20,30)
c=Shape1.Circle(5,20,30)
print(c.area())
print(repr(p))
print(repr(c))
print(c.radius)