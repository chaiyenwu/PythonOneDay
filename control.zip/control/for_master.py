words = ["airplane","car","dog","bear","bird"]
for w in words:
    print(w,len(w))
    print(w+"helloworld")