words =['airplane','cat','dog','bear','car']
for w in words:
    print(w,len(w))