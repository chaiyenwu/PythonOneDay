x = True
y = False
z = x and y
print(z)
z1 = x or y
print(z1)
z2 = not x
print(z2)
z3 = not y
print(z3)