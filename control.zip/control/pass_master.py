def Hello():
    pass

Hello()
print('Hello World')