def Hello():
    pass

Hello()
print("Helloworld")