x=8
if x > 5:
    print("X大於5")