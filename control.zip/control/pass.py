while True:
    pass #Ctrl+c為跳出 Windows 「Ctrl + C」 / Mac 「Command + C」

print("pass沒做任何事")