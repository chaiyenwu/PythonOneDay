if (3 > 5) :
    print("3大於5")

if (3 < 5) :
    print("3小於5")

if (5==5) :
    print("5等於5")

if (3>5) or (3<5) :
    print("只要有一個成立就為真")

if (not(3>5)):
    print("不會3大於5,這是真")

if (3>5) and (3<5) :
    print("HelloWorld")