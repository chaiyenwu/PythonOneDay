a=20
while a < 25 :
    a=a+1
    print(a)

