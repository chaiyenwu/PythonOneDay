#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  6 10:10:31 2018

@author: justinwu
"""

i = 5

def f(arg=i):
    print(arg)

i = 6
f()

