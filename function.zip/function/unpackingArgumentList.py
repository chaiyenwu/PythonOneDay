#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  6 10:24:21 2018

@author: justinwu
"""

print(list(range(3, 6)))

args = [3, 6]

print(list(range(*args)))