#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 13:53:22 2018

@author: justinwu
"""

i=5

def f(arg=i):
    print(arg)

i=6

f()