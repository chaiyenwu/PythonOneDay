#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  6 10:30:53 2018

@author: justinwu
"""

def my_function():
     """文件說明.

     這沒有作任何事.
     """
     pass
 
print(my_function.__doc__)