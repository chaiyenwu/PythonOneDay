use company
exec select_emp_parameter3 