declare @proc_var char(30)
set @proc_var = 'select_emp'
use company
exec @proc_var