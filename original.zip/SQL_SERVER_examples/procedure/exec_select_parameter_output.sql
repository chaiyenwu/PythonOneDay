use company
declare @mySalary int
exec select_emp_parameter_output_salary 12,@salary = @mySalary output
print convert(varchar,@mySalary) 