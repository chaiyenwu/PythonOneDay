use company
exec select_emp_parameter 80000,12,15