use company
declare @var int
exec @var=select_emp_parameter5
print convert(varchar,@var) 