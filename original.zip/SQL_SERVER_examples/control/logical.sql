print '&'
select 1 & 1 
select 1 & 0
print '|'
select 1 | 0
select 1|1
print '^'
select 1 ^ 0
select 1 ^ 1