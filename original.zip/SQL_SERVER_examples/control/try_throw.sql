begin try
	select 20/0
end try
begin catch
	--divide by 0
	throw 88899,'divide by 0',1
end catch