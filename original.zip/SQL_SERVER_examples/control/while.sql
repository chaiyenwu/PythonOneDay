declare @a int
declare @total int,@count int
set @total = 0
set @count =0
while @count <=10
begin
	set @count = @count +1
	set @total = @total +@count
	print 'total:' + cast(@total as char)
end