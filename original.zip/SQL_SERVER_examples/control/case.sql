begin
use company
declare @month varchar(20)
declare @my_var int
set @my_var =2
set @month =
case 
    when @my_var =1 then  'january'
	when @my_var=2 then 'febrary'
	when @my_var=3 then 'march'
	else '�䥦'
end 
print @month
end