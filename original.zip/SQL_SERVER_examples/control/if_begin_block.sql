declare @x int
set @x = 15
if @x <10
begin
declare @num_1 int,@num_2 int
set @num_1 = 5
set @num_2 = 10
print @num_1+@num_2
end
else if @x<20 and @x >10
begin
print '10<@x<20'
end
else
begin
print '@x>20'
end

