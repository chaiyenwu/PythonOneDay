declare @x1 int,@x2 int,@y1 int,@y2 int,@y3 int,@y4 int,@y5 int

set @x1 =1
set @x2 =2
set @y1 =@x1 + @x2*3
print @y1
set @y2 = @x2/@x1
print @y2
set @y3 = @x1 *@x2+6/@x2
print @y3
set @y4 =  5
print @y4
print '�ഫ'+cast(@y4 as char)
set @y5 = 9
print '���A�ഫ'+convert(char,@y5)