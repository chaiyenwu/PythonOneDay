begin
declare @num_1 int,@num_2 int
set @num_1 = 5
set @num_2 = 10
print @num_1+@num_2
end