declare @num_1 int,@num_2 int,@num_3 int;
set @num_1 = 5;
set @num_2=10;
set @num_3= @num_1+@num_2;
print @num_3