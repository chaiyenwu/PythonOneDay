declare @localvariable  int
	set @localvariable = 20

 go
 select @localvariable
 go