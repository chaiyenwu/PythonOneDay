begin try
	raiserror(88899,16,5)
end try
begin catch
	-- start to catch the exception
	select ERROR_MESSAGE() as ERRORMessage,
	error_state() as errorState,
	ERROR_PROCEDURE() as error_procedure,
	ERROR_SEVERITY() as error_severity,
	ERROR_NUMBER() as error_number
end catch