use company
select * from dbo.emp_relative_company2()
