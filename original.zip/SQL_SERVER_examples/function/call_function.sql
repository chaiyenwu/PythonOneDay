use company
print convert(varchar,dbo.emp_salary(12))
