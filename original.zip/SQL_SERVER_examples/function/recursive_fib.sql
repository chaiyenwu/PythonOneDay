create function fib
(@var int)
returns int
as
begin
 declare @ans int
if(@var =0)
 set @ans =0
else if @var=1
 set @ans =1
 ELSE
 set @ans = dbo.fib(@var -1)+dbo.fib(@var -2)

 return @ans
end