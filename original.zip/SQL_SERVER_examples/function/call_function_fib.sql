use company
select * from dbo.emp_company()
