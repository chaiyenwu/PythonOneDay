#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:42:38 2017

@author: justinwu
"""

def addf(x,y):
    print(x+y)
    
i1=23
i2=12
addf(i1,i2)
