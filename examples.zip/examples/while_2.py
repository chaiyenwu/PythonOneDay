#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 14:09:11 2017

@author: justinwu
"""
i=5
x=True
while x:
    print("i:",i)
    i=i+1
    if(i>=10):
        break
    
            