#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 14:30:21 2017

@author: justinwu
"""
X=True
y=False
print(x&y)
print(x|y)
if (x&y):
    print(x&y)
else:
    print(x&y)
z=True
print(z&y)
print(z|y)
