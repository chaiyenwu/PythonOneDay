#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 11:45:00 2017

@author: justinwu
"""

for i in range(8,19):
    print("i的值:",i)