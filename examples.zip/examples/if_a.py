#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 14:02:42 2017

@author: justinwu
"""

a=int(input("請輸入薪水:"))
if a < 50000:
    print('薪水小於50000')
else:
    print('薪水大於或等於50000')    