#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 27 19:40:39 2017

@author: justinwu
"""
tel={Justin:0920909872,Ivy:0922876895}
d2={}
