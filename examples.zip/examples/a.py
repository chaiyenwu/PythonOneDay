#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:37:16 2017

@author: justinwu
"""

a = 5
while a <=10:
    print("a:",a)
    a=a+1