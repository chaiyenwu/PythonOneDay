#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 16:45:33 2017

@author: justinwu
"""

def myreturn3(a,x=2,y=3):
    return a*x*y

i3=2
i5=5

print(myreturn3(8,i3,i5))

